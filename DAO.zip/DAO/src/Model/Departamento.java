package Model;

import java.util.Objects;

public class Departamento {
	private int id;
	private String nome;
	private String sigla;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSigla() {
		return sigla;
	}
	public void setSigla(String sigla) {
		this.sigla = sigla;
	}
	public Departamento(int id, String nome, String sigla) {		
		this.id = id;
		this.nome = nome;
		this.sigla = sigla;
	}
	public Departamento() {
		
	}
	@Override
	public String toString() {
		return "Departamento [id=" + id + ", nome=" + nome + ", sigla=" + sigla + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(id, nome, sigla);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Departamento other = (Departamento) obj;
		return id == other.id && Objects.equals(nome, other.nome) && Objects.equals(sigla, other.sigla);
	}		
}
