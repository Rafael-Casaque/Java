package Model;

import java.util.Objects;

public class Funcionario {
	private int id;
	private String cpf;
	private String nome;
	private Departamento departamento;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Departamento getDepartamento() {
		return departamento;
	}
	public void setDepartamento(Departamento departamento) {
		this.departamento = departamento;
	}
	public Funcionario(int id, String cpf, String nome, Departamento departamento) {		
		this.id = id;
		this.cpf = cpf;
		this.nome = nome;
		this.departamento = departamento;
	}
	public Funcionario() {
		
	}
	@Override
	public String toString() {
		return "Funcionario [id=" + id + ", cpf=" + cpf + ", nome=" + nome + ", departamento=" + departamento + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(cpf, departamento, id, nome);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Funcionario other = (Funcionario) obj;
		return Objects.equals(cpf, other.cpf) && Objects.equals(departamento, other.departamento) && id == other.id
				&& Objects.equals(nome, other.nome);
	}		
}
