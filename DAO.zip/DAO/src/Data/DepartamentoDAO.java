package Data;

import java.util.List;

import Model.Departamento;

public interface DepartamentoDAO extends DAO <Departamento> {
	void salvar (Departamento departamento);
	void atualizar (Departamento departamento);
	void apagar (Departamento departamento);
	Departamento buscar (int param);
	List<Departamento> buscarTodos();
}
