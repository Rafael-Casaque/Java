package Data;

import java.util.List;

import Model.Departamento;

public class DepartamentoSQLiteDAO implements DepartamentoDAO{

	@Override
	public void salvar(Departamento departamento) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void atualizar(Departamento departamento) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void apagar(Departamento departamento) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Departamento buscar(int param) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Departamento> buscarTodos() {
		// TODO Auto-generated method stub
		return null;
	}	
}
