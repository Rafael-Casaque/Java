package Data;

import java.util.List;

import Model.Funcionario;

public interface FuncionarioDAO extends DAO <Funcionario> {
	void salvar (Funcionario departamento);
	void atualizar (Funcionario departamento);
	void apagar (Funcionario departamento);
	Funcionario buscar (int param);
	List<Funcionario> buscarTodos();
}
