package Data;

import java.util.List;

import Model.Funcionario;

public class FuncionarioSQLiteDAO implements FuncionarioDAO{

	@Override
	public void salvar(Funcionario departamento) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void atualizar(Funcionario departamento) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void apagar(Funcionario departamento) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Funcionario buscar(int param) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Funcionario> buscarTodos() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
